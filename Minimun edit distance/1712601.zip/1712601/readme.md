
# Hướng dẫn cách build chương trình

- Gõ lệnh tại terminal để cài đặt package **auto-py-to-exe 2.7.10**.

```
pip install auto-py-to-exe
```

- Gõ tiếp lệnh dưới để khởi động **auto-py-to-exe**.

```
auto-py-to-exe
```

- Sau khi giao diện auto-py-to-exe hiện lên:
	- Ở mục ```Script Location``` chọn đường dẫn (path) tới ```1712601.py```.
	- Ở mục ```Onefile (--onedir / --onefile)``` chọn out put là ```một thư mục/một file```.
	- Ở mục ```Console Window (--console / --windowed)``` chọn 
		
		```windowed Based (hide the console)```.
	- Click vào ```CONVERT .PY TO .EXE```


* File output sẽ lưu ở thư mục **output** hoặc đơn giản là nhấp vào ```OPEN OUTPUT FOLDER``` sau khi chạy xong